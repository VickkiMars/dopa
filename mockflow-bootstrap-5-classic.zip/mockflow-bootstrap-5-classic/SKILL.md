---
name: mockflow-bootstrap-5-classic
description: Standard web layouts using the iconic Bootstrap 5 framework aesthetic Trigger on: Design, bootstrap, framework, web, standard, classic, ui.
allowed-tools: mcp__claude_ai_WireframePro__render_wireframe
---

# Bootstrap 5 Classic

## Requirements
- MockFlow WireframePro MCP server (desktop on port 21194 or CLI install via npm)

## Author
MockFlow

## Category
design

## Output Type
wireframe

## Instructions
Design screens using the classic Bootstrap 5 framework aesthetic. Use a clean white background (#FFFFFF) with a light gray surface (#F8F9FA) for sidebars and headers. Text uses dark gray (#212529) for body and headings, with secondary text in a muted gray (#6C757D). The primary accent color is a vibrant blue (#0D6EFD) for buttons and links, with success in green (#198754) and danger in red (#DC3545). Use Source Sans Pro for all typography. Navigation remains standard with a dark or light top navbar and a simple brand logo on the left. Buttons are rectangular with slightly rounded corners (4px radius) and solid color fills. Input fields are white with a light gray border and 4px radius. Cards are simple white boxes with a thin gray border (#DEE2E6) and no shadows. Layouts follow a standard 12-column grid system with clear visual hierarchies and standard 16px gutters. Overall feel: professional, structured, and familiar to web users.

## Input examples
Describe a screen (e.g. "a user profile settings page" or "a data analytics dashboard")

## Output
Call the `render_wireframe` MCP tool from MockFlow WireframePro to render the result.
